package edu.westga.comp2320.dining.resources;

import java.text.NumberFormat;
import java.util.Locale;

/**
 * Provides utilities for the project.
 *
 * @author COMP2320
 * @version Fall 2023
 */
public class Utilities {

  /**
   * Format specified value as a US currency, with comma as thousands separator
   * and exactly two digits after the decimal point.
   *
   * @precondition
   * @postcondition
   * @param value to format
   * @return formatted value
   */
  public static String formatAsCurency(double value) {
    NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(Locale.US);
    return (currencyFormatter.format(value));
  }
}
