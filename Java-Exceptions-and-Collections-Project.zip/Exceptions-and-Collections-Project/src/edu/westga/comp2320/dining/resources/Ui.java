package edu.westga.comp2320.dining.resources;

/**
 * This User Interface (uI) class defines string messages for exceptions.
 *
 * @author COMP2320
 * @version Fall 2023
 */
public class Ui {

  // model
  public static final String NULL_CHAIN = "The chain cannot be null.";
  public static final String NULL_NAME = "Name cannot be null.";
  public static final String BLANK_NAME = "Name cannot be blank.";
  public static final String RATING_OUT_OF_BOUNDS = "Rating out of bounds.";
  public static final String TABLE_NUMBER_OUT_OF_BOUNDS = "Table number out of bounds.";
  public static final String NUMBER_SEATS_OUT_OF_BOUNDS = "Number of seats out of bounds.";
  public static final String NULL_TABLES = "Tables cannot be null.";
  public static final String NULL_TABLE = "Table cannot be null.";
  public static final String EXISTING_TABLE = "Table with the same number already exists.";
  public static final String NON_POSITIVE_PAYMENT = "Payment must be a positive value.";

  // data tier
  public static final String FILE_CANNOT_BE_NULL = "File cannot be null.";
  public static final String FILE_NOT_FOUND = "File not found.";
  public static final String NULL_RESTAURANT = "Resturant cannot be null.";
  public static final String NO_DATA_AVAILABLE =
      "There is no data available to generate a summary.";
  public static final String INCOMPLETE_DATA = "Incomplete data.";
  public static final String INCORRECT_AVAILABILITY = "Availability incorrectly specified.";
  public static final String INVALID_RANGE = "The range is invalid.";

}
