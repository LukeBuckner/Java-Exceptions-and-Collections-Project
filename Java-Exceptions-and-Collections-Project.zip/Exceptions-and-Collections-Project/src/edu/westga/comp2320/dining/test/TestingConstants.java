package edu.westga.comp2320.dining.test;

/**
 * Testing constants for the restaurant app.
 *
 * @author COMP2320
 * @version Fall 2023
 */
public class TestingConstants {

  public static final double DELTA = 0.1;

}
