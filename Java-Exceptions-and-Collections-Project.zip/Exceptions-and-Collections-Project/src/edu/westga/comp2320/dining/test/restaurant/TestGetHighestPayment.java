package edu.westga.comp2320.dining.test.restaurant;

import static org.junit.jupiter.api.Assertions.assertEquals;

import edu.westga.comp2320.dining.model.PaymentHistory;
import org.junit.jupiter.api.Test;

/**
 * Ensures Functionality of the PaymentHistory Class' Getter methods.
 */
class TestGetHighestPayment {

  @Test
  public void testGetHighestPaymentWithEmptyHistoryShouldReturnZero() {
    PaymentHistory history = new PaymentHistory();
    assertEquals(0.0, history.getHighestPayment());
  }

  @Test
  public void testGetHighestPaymentWithMultiplePaymentsShouldReturnHighestPayment() {
    PaymentHistory history = new PaymentHistory();
    history.add(25.0);
    history.add(30.0);
    history.add(20.0);
    assertEquals(30.0, history.getHighestPayment());
  }

}
