package edu.westga.comp2320.dining.test.restaurant;

import static org.junit.jupiter.api.Assertions.assertEquals;

import edu.westga.comp2320.dining.model.Restaurant;
import edu.westga.comp2320.dining.model.Table;
import edu.westga.comp2320.dining.test.TestingConstants;
import org.junit.jupiter.api.Test;

/**
 * Ensures correct functionality of the Restaurant class.
 *
 * @author COMP2320
 * @version Fall 2023
 */
public class TestGetAverageNumberSeats {

  @Test
  void testNoTables() {
    Restaurant restaurant = new Restaurant();
    assertEquals(0, restaurant.getAverageNumberSeats(), TestingConstants.DELTA);

  }

  @Test
  void testOneTable() {
    Restaurant restaurant = new Restaurant();
    Table table = new Table(5, 18);
    restaurant.add(table);
    assertEquals(18, restaurant.getAverageNumberSeats(), TestingConstants.DELTA);
  }

  @Test
  void testMultipleTables() {
    Restaurant restaurant = new Restaurant();
    Table table1 = new Table(3, 5);
    restaurant.add(table1);
    Table table2 = new Table(4, 6);
    restaurant.add(table2);
    Table table3 = new Table(5, 8);
    restaurant.add(table3);

    assertEquals(6.33, restaurant.getAverageNumberSeats(), TestingConstants.DELTA);
  }

}
