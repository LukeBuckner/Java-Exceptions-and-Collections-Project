package edu.westga.comp2320.dining.test.table;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import edu.westga.comp2320.dining.model.Table;
import edu.westga.comp2320.dining.resources.Ui;
import org.junit.jupiter.api.Test;

/**
 * Ensures correct functionality of the Table constructor(s).
 *
 * @author COMP2320
 * @version Fall 2023
 */
public class TestConstructor {

  @Test
  void testValidConstruction() {
    Table table = new Table(3, 5);
    assertAll(() -> assertEquals(3, table.getTableNumber()), () 
        -> assertEquals(5, table.getNumberOfSeats()));
  }

  @Test
  void testValidConstructionAtLowerBounds() {
    Table table = new Table(Table.MIN_TABLE_NUMBER, Table.MIN_NUMBER_SEATS);
    assertAll(() -> assertEquals(Table.MIN_TABLE_NUMBER, table.getTableNumber()),
        () -> assertEquals(Table.MIN_NUMBER_SEATS, table.getNumberOfSeats()));
  }

  @Test
  void testValidConstructionAtUpperBounds() {
    Table table = new Table(Table.MAX_TABLE_NUMBER, Table.MAX_NUMBER_SEATS);
    assertAll(() -> assertEquals(Table.MAX_TABLE_NUMBER, table.getTableNumber()),
        () -> assertEquals(Table.MAX_NUMBER_SEATS, table.getNumberOfSeats()));
  }

  @Test
  void testTableNumberBelowLowerBound() {
    Exception ex = assertThrows(IllegalArgumentException.class, 
        () -> new Table(Table.MIN_TABLE_NUMBER - 1, 5));
    assertEquals(Ui.TABLE_NUMBER_OUT_OF_BOUNDS, ex.getMessage());
  }

  @Test
  void testTableNumberAboveLowerBound() {
    Exception ex = assertThrows(IllegalArgumentException.class, 
        () -> new Table(Table.MAX_TABLE_NUMBER + 1, 5));
    assertEquals(Ui.TABLE_NUMBER_OUT_OF_BOUNDS, ex.getMessage());
  }

  @Test
  void testNumberSeatsBelowLowerBound() {
    Exception ex = assertThrows(IllegalArgumentException.class, 
        () -> new Table(3, Table.MIN_NUMBER_SEATS - 1));
    assertEquals(Ui.NUMBER_SEATS_OUT_OF_BOUNDS, ex.getMessage());
  }

  @Test
void testNumberSeatsAboveUpperBound() {
    Exception ex = assertThrows(IllegalArgumentException.class, ()
        -> new Table(3, Table.MAX_NUMBER_SEATS + 1));
    assertEquals(Ui.NUMBER_SEATS_OUT_OF_BOUNDS, ex.getMessage());
  }

}
