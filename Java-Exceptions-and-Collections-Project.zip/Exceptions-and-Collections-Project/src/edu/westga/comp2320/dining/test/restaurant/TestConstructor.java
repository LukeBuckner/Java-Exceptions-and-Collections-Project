package edu.westga.comp2320.dining.test.restaurant;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import edu.westga.comp2320.dining.model.Restaurant;
import edu.westga.comp2320.dining.resources.Ui;
import org.junit.jupiter.api.Test;

/**
 * Ensures correct functionality of the Restaurant class.
 *
 * @author COMP2320
 * @version Fall 2023
 */
public class TestConstructor {

  @Test
  void testZeroParamConstructor() {
    Restaurant restaurant = new Restaurant();
    assertAll(() -> assertEquals("", restaurant.getName()),
        () -> assertEquals(Restaurant.DEFAULT_RATING_VALUE, restaurant.getRating()),
        () -> assertEquals(0, restaurant.size()));
  }

  @Test
  void testValidConstruction() {
    Restaurant restaurant = new Restaurant("Marcos", 4);
    assertAll(() -> assertEquals("Marcos", restaurant.getName()), 
        () -> assertEquals(4, restaurant.getRating()),
        () -> assertEquals(0, restaurant.size()));
  }

  @Test
  void testNullName() {
    Exception ex = assertThrows(IllegalArgumentException.class, () -> new Restaurant(null, 5));
    assertEquals(Ui.NULL_NAME, ex.getMessage());
  }

  @Test
  void testBlankName() {
    Exception ex = assertThrows(IllegalArgumentException.class, () -> new Restaurant("", 5));
    assertEquals(Ui.BLANK_NAME, ex.getMessage());
  }

  @Test
  void testRatingBelowBound() {
    Exception ex = assertThrows(IllegalArgumentException.class,
        () -> new Restaurant("Marcos", Restaurant.MIN_RATING - 1));
    assertEquals(Ui.RATING_OUT_OF_BOUNDS, ex.getMessage());
  }

  @Test
  void testRatingAboveBound() {
    Exception ex = assertThrows(IllegalArgumentException.class,
        () -> new Restaurant("Marcos", Restaurant.MAX_RATING + 1));
    assertEquals(Ui.RATING_OUT_OF_BOUNDS, ex.getMessage());
  }

  @Test
  void testRatingWellBelowBound() {
    Exception ex = assertThrows(IllegalArgumentException.class,
        () -> new Restaurant("Marcos", Restaurant.MIN_RATING - 10));
    assertEquals(Ui.RATING_OUT_OF_BOUNDS, ex.getMessage());
  }

  @Test
  void testRatingWellAboveBound() {
    Exception ex = assertThrows(IllegalArgumentException.class,
        () -> new Restaurant("Marcos", Restaurant.MAX_RATING + 10));
    assertEquals(Ui.RATING_OUT_OF_BOUNDS, ex.getMessage());
  }

  @Test
  void testRatingAtLowerBound() {
    Restaurant restaurant = new Restaurant("Marcos", Restaurant.MIN_RATING);
    assertAll(() -> assertEquals("Marcos", restaurant.getName()),
        () -> assertEquals(Restaurant.MIN_RATING, restaurant.getRating()),
        () -> assertEquals(0, restaurant.size()));
  }

  @Test
  void testRatingAtUpperrBound() {
    Restaurant restaurant = new Restaurant("Marcos", Restaurant.MAX_RATING);
    assertAll(() -> assertEquals("Marcos", restaurant.getName()),
        () -> assertEquals(Restaurant.MAX_RATING, restaurant.getRating()),
        () -> assertEquals(0, restaurant.size()));
  }

}
