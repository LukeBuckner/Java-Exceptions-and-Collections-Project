package edu.westga.comp2320.dining.test.restaurant;

import static org.junit.jupiter.api.Assertions.assertEquals;

import edu.westga.comp2320.dining.model.Restaurant;
import edu.westga.comp2320.dining.model.Table;
import org.junit.jupiter.api.Test;

/**
 * Ensures correct functionality of the Restaurant class.
 *
 * @author COMP2320
 * @version Fall 2023
 */
public class TestGetNumberSeatsAtLargestTable {

  @Test
  void testNoTable() {
    Restaurant restaurant = new Restaurant();
    assertEquals(0, restaurant.getNumberSeatsAtLargestTable());
  }

  @Test
  void testOneTable() {
    Restaurant restaurant = new Restaurant();
    Table table1 = new Table(1, 5);
    restaurant.add(table1);
    assertEquals(5, restaurant.getNumberSeatsAtLargestTable());
  }

  @Test
  void testMultipleTables() {
    Restaurant restaurant = new Restaurant();
    Table table1 = new Table(1, 5);
    restaurant.add(table1);
    Table table2 = new Table(2, 15);
    restaurant.add(table2);
    Table table3 = new Table(3, 7);
    restaurant.add(table3);
    assertEquals(15, restaurant.getNumberSeatsAtLargestTable());
  }

  @Test
  void testMaxFirst() {
    Restaurant restaurant = new Restaurant();
    Table table1 = new Table(1, 18);
    restaurant.add(table1);
    Table table2 = new Table(2, 15);
    restaurant.add(table2);
    Table table3 = new Table(3, 7);
    restaurant.add(table3);
    assertEquals(18, restaurant.getNumberSeatsAtLargestTable());
  }

  @Test
  void testMaxLast() {
    Restaurant restaurant = new Restaurant();
    Table table1 = new Table(1, 2);
    restaurant.add(table1);
    Table table2 = new Table(2, 15);
    restaurant.add(table2);
    Table table3 = new Table(3, 20);
    restaurant.add(table3);
    assertEquals(20, restaurant.getNumberSeatsAtLargestTable());

  }

  @Test
  void testMultipleMaxima() {
    Restaurant restaurant = new Restaurant();
    Table table1 = new Table(1, 17);
    restaurant.add(table1);
    Table table2 = new Table(2, 15);
    restaurant.add(table2);
    Table table3 = new Table(3, 17);
    restaurant.add(table3);
    assertEquals(17, restaurant.getNumberSeatsAtLargestTable());
  }

}
