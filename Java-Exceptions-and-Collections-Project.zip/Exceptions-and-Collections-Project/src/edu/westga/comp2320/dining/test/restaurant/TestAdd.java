package edu.westga.comp2320.dining.test.restaurant;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import edu.westga.comp2320.dining.model.Restaurant;
import edu.westga.comp2320.dining.model.Table;
import edu.westga.comp2320.dining.resources.Ui;
import org.junit.jupiter.api.Test;

/**
 * Ensures correct functionality of the Restaurant class.
 *
 * @author COMP2320
 * @version Fall 2023
 */
public class TestAdd {

  @Test
  void testNullArgument() {
    Restaurant restaurant = new Restaurant();
    Exception ex = assertThrows(IllegalArgumentException.class, 
        () -> restaurant.add(null));
    assertEquals(Ui.NULL_TABLE, ex.getMessage());
  }

  @Test
  void testAddToEmptyRestaurant() {
    Restaurant restaurant = new Restaurant();
    Table table1 = new Table(3, 5);
    restaurant.add(table1);

    assertAll(() -> assertThrows(IllegalArgumentException.class, 
        () -> restaurant.add(table1)),
        () -> assertEquals(1, restaurant.size()));
  }

  @Test
  void testAddExistingTable() {
    Restaurant restaurant = new Restaurant();
    Table table1 = new Table(3, 5);
    restaurant.add(table1);

    Table table2 = new Table(3, 6);
    assertAll(() -> assertThrows(IllegalArgumentException.class, 
        () -> restaurant.add(table2)),
        () -> assertEquals(1, restaurant.size()));
  }

  @Test
  void testAddMultipleTables() {
    Restaurant restaurant = new Restaurant();
    Table table1 = new Table(3, 5);
    restaurant.add(table1);
    Table table2 = new Table(4, 6);
    restaurant.add(table2);

    Table table3 = new Table(3, 7);
    assertAll(() -> assertThrows(IllegalArgumentException.class, 
        () -> restaurant.add(table3)),
        () -> assertEquals(2, restaurant.size()));
  }

}
