package edu.westga.comp2320.dining.test.restaurant;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import edu.westga.comp2320.dining.model.Restaurant;
import edu.westga.comp2320.dining.model.Table;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;

/**
 *  Ensures functionality of the Get Payment methods of the Restaurant Class.
 */
public class TestGetRestaurantPayments {

  @Test
  public void testGetTotalNumberOfPayments() {
    Restaurant test = new Restaurant("Test Restaurant", 5);
    Table table1 = new Table(1, 4);
    Table table2 = new Table(2, 6);

    // Add tables to the restaurant
    test.add(table1);
    test.add(table2);

    // Add some payments to tables
    table1.collectPayment(20.0);
    table1.collectPayment(25.0);
    table2.collectPayment(15.0);

    assertEquals(3, test.getTotalNumberOfPayments());
  }

  @Test
  public void testGetHighestPayment() {
    Restaurant test = new Restaurant("Test Restaurant", 5);
    Table table1 = new Table(1, 4);
    Table table2 = new Table(2, 6);

    // Add tables to the restaurant
    test.add(table1);
    test.add(table2);

    // Add some payments to tables
    table1.collectPayment(20.0);
    table1.collectPayment(25.0);
    table2.collectPayment(15.0);
    assertEquals(25.0, test.getHighestPayment());
  }

  @Test
  public void testGetLowestPayment() {
    Restaurant test = new Restaurant("Test Restaurant", 5);
    Table table1 = new Table(1, 4);
    Table table2 = new Table(2, 6);

    // Add tables to the restaurant
    test.add(table1);
    test.add(table2);

    // Add some payments to tables
    table1.collectPayment(20.0);
    table1.collectPayment(25.0);
    table2.collectPayment(15.0);
    assertEquals(15.0, test.getLowestPayment());
  }

  @Test
  public void testGetAllPayments() {
    Restaurant test = new Restaurant("Test Restaurant", 5);
    Table table1 = new Table(1, 4);
    Table table2 = new Table(2, 6);

    // Add tables to the restaurant
    test.add(table1);
    test.add(table2);

    // Add some payments to tables
    table1.collectPayment(20.0);
    table1.collectPayment(25.0);
    table2.collectPayment(15.0);
    List<Double> expectedPayments = Arrays.asList(20.0, 25.0, 15.0);
    List<Double> actualPayments = test.getAllPayments();
    
    assertTrue(
        actualPayments.containsAll(expectedPayments)
        && expectedPayments.containsAll(actualPayments)
    );
  }
}
