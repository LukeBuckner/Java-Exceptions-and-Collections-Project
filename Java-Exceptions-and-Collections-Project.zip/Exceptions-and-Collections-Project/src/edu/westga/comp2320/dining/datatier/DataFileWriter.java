package edu.westga.comp2320.dining.datatier;

import edu.westga.comp2320.dining.model.Chain;
import edu.westga.comp2320.dining.model.Restaurant;
import edu.westga.comp2320.dining.model.Table;
import edu.westga.comp2320.dining.resources.Ui;
import edu.westga.comp2320.dining.resources.Utilities;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.List;

/**
 * Writes data to a csv file.
 *
 * @author COMP2320
 * @version Fall 2023
 */
public class DataFileWriter {

  private File outputFile;

  /**
   * Instantiate a new DataFileWriter.
   *
   * @precondition inputFile != null
   * @postcondition none
   * @param outputFile the output data file
   */
  public DataFileWriter(File outputFile) {
    if (outputFile == null) {
      throw new IllegalArgumentException(Ui.FILE_CANNOT_BE_NULL);
    }
    this.outputFile = outputFile;
  }

  /**
   * Write all Table objects from the specified restaurant to the data file. Each
   * Table will be written on a separate line following this format:
   * tableNumber,numberOfSeats,availability,paymentAverage
   *
   * @precondition restaurant != null
   * @postcondition none
   * @param restaurant the restaurant whose tables will be written to outputFile
   */
  public void writeTableData(Restaurant restaurant) {
    // TODO as Part of Lab 3 (not used in this project)
    if (restaurant == null) {
      throw new IllegalArgumentException(Ui.NULL_RESTAURANT);
    }

    try (PrintWriter writer = new PrintWriter(this.outputFile)) {
      for (Table table : restaurant.getTables()) {
        String output = this.formatTable(table);
        writer.println(output);
      }
    } catch (FileNotFoundException ex) {
      System.err.println(Ui.FILE_NOT_FOUND);
    }
  }

  private String formatTable(Table table) {
    String output = table.getTableNumber() + FormattingConstants.FIELD_SEPARATOR;
    output += table.getNumberOfSeats() + FormattingConstants.FIELD_SEPARATOR;
    output += this.formatAvailability(table) + FormattingConstants.FIELD_SEPARATOR;
    double value = table.getPaymentHistory().getAverage();
    output += Utilities.formatAsCurency(value);
    return output;
  }

  private String formatAvailability(Table table) {
    if (table.isAvailable()) {
      return FormattingConstants.TABLE_AVAILABLE;
    }
    return FormattingConstants.TABLE_NOT_AVAILABLE;
  }

  /**
   * Write all data from the specified chain to the file: Restaurant:name:rating
   * on one line, followed by tableNumber,numberOfSeats,availability,list of
   * payments on one line, for each table.
   *
   * @precondition chain != null
   * @postcondition none
   * @param chain the chain whose data will be written to outputFile
   */
  public void writeRestaurantData(Chain chain) {
    if (chain == null) {
      throw new IllegalArgumentException(Ui.NULL_CHAIN);
    }

    try (PrintWriter writer = new PrintWriter(this.outputFile)) {
      for (Restaurant restaurant : chain.getRestaurants()) {
        writer.println("Restaurant," + restaurant.getName() + "," + restaurant.getRating());

        for (Table table : restaurant.getTables()) {
          writer.print(table.getTableNumber() + ",");
          writer.print(table.getNumberOfSeats() + ",");
          writer.print(table.isAvailable() ? "yes," : "no,");

          List<Double> payments = table.getPaymentHistory().getPayments();
          for (Double payment : payments) {
            writer.print(Utilities.formatAsCurency(payment) + ",");
          }

          writer.println(); 
        }
      }
    } catch (FileNotFoundException ex) {
      System.err.println(Ui.FILE_NOT_FOUND);
    }
  }
}
