package edu.westga.comp2320.dining.datatier;

import edu.westga.comp2320.dining.model.Chain;
import edu.westga.comp2320.dining.model.Restaurant;
import edu.westga.comp2320.dining.model.Table;
import edu.westga.comp2320.dining.resources.Ui;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Writes report data to a text file.
 * This class is responsible for generating a report 
 *                for a given chain and writing it to a specified file.
 * The report includes payment segments for each restaurant in the chain.
 *
 * @author COMP2320
 * @version Fall 2023
 */
public class ReportFileWriter {

  private File reportFile;

  /**
   * Instantiate a new ReportFileWriter.
   *
   * @param reportFile the output data file for the report
   * @precondition reportFile != null
   * @postcondition none
   */
  public ReportFileWriter(File reportFile) {
    if (reportFile == null) {
      throw new IllegalArgumentException(Ui.FILE_CANNOT_BE_NULL);
    }
    this.reportFile = reportFile;
  }

  /**
   * Writes the report data for the specified chain.
   *
   * @param chain the chain to generate the report for
   * @param range the range used to calculate payment segments
   * @precondition chain != null
   * @postcondition none
   */
  public void writeReportData(Chain chain, int range) {
    try (PrintWriter writer = new PrintWriter(this.reportFile)) {
      List<Restaurant> restaurants = chain.getRestaurants();
      int restaurantCount = 1;

      for (Restaurant restaurant : restaurants) {
        writer.println(restaurantCount + ". " + restaurant.getName());
        List<PaymentSegment> segments = calculateSegments(restaurant, range);

        if (segments.isEmpty()) {
          writer.println(Ui.NO_DATA_AVAILABLE);
        } else {
          writer.println("Min payment $          Max payment $         Number payments");
          for (PaymentSegment segment : segments) {
            writer.println(segment.formatSegment());
          }
          writer.println("------------------------------------------------------------");
        }

        restaurantCount++;
      }
    } catch (FileNotFoundException ex) {
      System.err.println(Ui.FILE_NOT_FOUND);
    }
  }

  /**
   * Gets the report file.
   *
   * @return the report file
   */
  public File getReportFile() {
    return reportFile;
  }

  /**
   * Sets the report file.
   *
   * @param reportFile the report file to set
   */
  public void setReportFile(File reportFile) {
    this.reportFile = reportFile;
  }

  private List<PaymentSegment> calculateSegments(Restaurant restaurant, int range) {
    List<PaymentSegment> segments = new ArrayList<>();
    double minPayment = Double.MAX_VALUE;
    double maxPayment = Double.MIN_VALUE;

    // Iterate through the restaurant's tables to calculate segments
    for (Table table : restaurant.getTables()) {
      for (Double payment : table.getPaymentHistory().getPayments()) {
        if (payment < minPayment) {
          minPayment = payment;
        }
        if (payment > maxPayment) {
          maxPayment = payment;
        }
      }
    }

    if (minPayment == Double.MAX_VALUE || maxPayment == Double.MIN_VALUE) {
      // No payments found, return an empty list of segments
      return segments;
    }

    // Calculate the number of segments based on the range
    int numSegments = (int) Math.ceil((maxPayment - minPayment) / range);

    // Initialize segments
    double currentStart = minPayment;
    double currentEnd = minPayment + range;

    for (int i = 0; i < numSegments; i++) {
      segments.add(new PaymentSegment(currentStart, currentEnd));
      currentStart = currentEnd;
      currentEnd += range;
    }

    // Assign payments to segments
    for (Table table : restaurant.getTables()) {
      for (Double payment : table.getPaymentHistory().getPayments()) {
        for (PaymentSegment segment : segments) {
          if (payment >= segment.startValue && payment <= segment.endValue) {
            segment.paymentCount++;
            break;
          }
        }
      }
    }

    return segments;
  }

  /**
   * Represents a payment segment with a start value, end value, and payment count.
   */
  static class PaymentSegment {
    private double startValue;
    private double endValue;
    private int paymentCount;

    /**
     * Creates a new PaymentSegment with the specified start and end values.
     *
     * @param startValue the start value of the segment
     * @param endValue   the end value of the segment
     */
    public PaymentSegment(double startValue, double endValue) {
      this.startValue = startValue;
      this.endValue = endValue;
      this.paymentCount = 0;
    }

    /**
     * Formats the payment segment as a string.
     *
     * @return the formatted payment segment string
     */
    public String formatSegment() {
      return String.format("%20s %20s %20s",
        formatCurrency(startValue),
        formatCurrency(endValue),
        paymentCount);
    }

    private String formatCurrency(double value) {
      DecimalFormat currencyFormat = new DecimalFormat("$#,##0.00");
      return currencyFormat.format(value);
    }
  }
}
