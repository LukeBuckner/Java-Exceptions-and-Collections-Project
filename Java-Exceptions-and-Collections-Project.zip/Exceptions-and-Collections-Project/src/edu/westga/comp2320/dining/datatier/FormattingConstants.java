package edu.westga.comp2320.dining.datatier;

/**
 * This class stores constants used for File IO.
 *
 * @author COMP2320
 * @version Fall 2023
 */
public class FormattingConstants {

  public static final String FIELD_SEPARATOR = ",";
  public static final String DELIMITER = ",|\n|\r\r|\\s+";
  public static final String KEYWORD = "Restaurant";
  public static final String TABLE_AVAILABLE = "yes";
  public static final String TABLE_NOT_AVAILABLE = "no";
  public static final int PAD = 20;
}
