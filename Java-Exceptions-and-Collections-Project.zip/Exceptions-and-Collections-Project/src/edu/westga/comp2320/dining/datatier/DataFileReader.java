package edu.westga.comp2320.dining.datatier;

import edu.westga.comp2320.dining.model.Chain;
import edu.westga.comp2320.dining.model.Restaurant;
import edu.westga.comp2320.dining.model.Table;
import edu.westga.comp2320.dining.resources.Ui;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;


/**
 * Reads data from a csv file.
 *
 * @author COMP2320
 * @version Fall 2023
 */
public class DataFileReader {

  private File inputFile;

  /**
   * Instantiate a new DataFileReader.
   *
   * @precondition inputFile != null
   * @postcondition none
   * @param inputFile the input data file
   */
  public DataFileReader(File inputFile) {
    if (inputFile == null) {
      throw new IllegalArgumentException(Ui.FILE_CANNOT_BE_NULL);
    }
    this.inputFile = inputFile;
  }

  /**
   * Read all the table data from the inputFile one line at a time where each line
   * contains information about the restaurant in the form (one a line):
   * Restaurant,name of restaurant,rating followed by lines representing tables
   * that belong to the aforementioned restaurant (one per line):
   * tableNumber,NumberOfSeats,availability,paymentHistory
   *
   * <p>Parse the data to create restaurants and to add corresponding tables to each
   * restaurant.
   *
   * @precondition chain != null
   * @postcondition none
   * @param chain the chain to load restaurants and tables to
   */
  public void loadRestaurantData(Chain chain) {
    if (chain == null) {
      throw new IllegalArgumentException(Ui.NULL_CHAIN);
    }

    Restaurant currentRestaurant = null;

    try (Scanner input = new Scanner(this.inputFile)) {
      int lineNumber = 1;
      while (input.hasNextLine()) {
        String line = input.nextLine();
        try {
          String[] tokens = line.split(FormattingConstants.FIELD_SEPARATOR);
          if (tokens.length == 0) {
            continue;
          }
          if (tokens[0].equalsIgnoreCase("Restaurant")) {
            if (currentRestaurant != null) {
              chain.add(currentRestaurant);
            }
            
            String name = tokens[1];
            int rating = Integer.parseInt(tokens[2]);
            currentRestaurant = new Restaurant(name, rating);
          } else if (currentRestaurant != null) {
            Table table = buildTable(line);
            currentRestaurant.add(table);
          } else {
            System.err.println("Line " + lineNumber + " is invalid. Incomplete data.");
          }
        } catch (NumberFormatException ex) {
          System.err.println("Line " + lineNumber + " is invalid. " + ex.getMessage());
        } catch (Exception ex) {
          System.err.println("Line " + lineNumber + " is invalid. " + ex.getMessage());
        }
        lineNumber++;
      }
      
      if (currentRestaurant != null) {
        chain.add(currentRestaurant);
      }
    } catch (FileNotFoundException ex) {
      System.err.println(Ui.FILE_NOT_FOUND + ex.getMessage());
    }
  }
  
  /**
   * Read all the table data from the inputFile one line at a time where each line.
   * contains information about the table in the format:
   * tableNumber,NumberOfSeats,availability,paymentHistory
   *
   * <p>Parse the data on each line to create Table objects and stores them in the
   * list of tables of the specified restaurant
   *
   * @precondition restaurant != null
   * @postcondition none
   * @param restaurant the restaurant to load tables to
   * @return a list of added tables
   */
  public ArrayList<Table> loadTableData(Restaurant restaurant) {
    // TODO as part of Lab 3
    if (restaurant == null) {
      throw new IllegalArgumentException(Ui.NULL_RESTAURANT);
    }
    ArrayList<Table> tables = new ArrayList<Table>();
    int lineNumber = 1;

    try (Scanner input = new Scanner(this.inputFile)) {
      while (input.hasNextLine()) {
        String line = input.nextLine();
        try {
          Table table = this.buildTable(line);
          restaurant.add(table);
          tables.add(table); 
        } catch (Exception ex) {
          System.err.println("Line " + lineNumber + " is invalid. " + ex.getMessage());
        }
        lineNumber++;
      }
    } catch (FileNotFoundException ex) {
      System.err.println(Ui.FILE_NOT_FOUND + ex.getMessage());
    }
    return tables;
  }

  /**
   * BUild table from specified data.
   *
   * @precondition line != null && line contains at least 3 tokens && third token
   *               represents availability as "yes" or "no" (case insensitive)
   * @postcondition none
   * @param line the specified data
   * @return the bUilt table
   * @throws NumberFormatException - if second token not parsable integer
   */
  private Table buildTable(String line) {
    String[] tokens = line.split(FormattingConstants.FIELD_SEPARATOR);

    if (tokens.length < 3) {
      throw new IllegalArgumentException(Ui.INCOMPLETE_DATA);
    }

    int tableNumber = Integer.parseInt(tokens[0]);
    int numberOfSeats = Integer.parseInt(tokens[1]);
    Table table = new Table(tableNumber, numberOfSeats);

    this.parseAndSetAvailability(tokens, table);
    this.parseAndSetPayments(tokens, table);

    return table;
  }

  private void parseAndSetPayments(String[] tokens, Table table) {
    int index = 3;
    while (index < tokens.length) {
      Double payment = Double.parseDouble(tokens[index]);
      table.collectPayment(payment);
      index++;
    }
  }

  private void parseAndSetAvailability(String[] tokens, Table table) {
    if (tokens[2].toLowerCase().equals(FormattingConstants.TABLE_AVAILABLE)) {
      table.setAvailable(true);
    } else if (tokens[2].toLowerCase().equals(FormattingConstants.TABLE_NOT_AVAILABLE)) {
      table.setAvailable(false);
    } else {
      throw new IllegalArgumentException(Ui.INCORRECT_AVAILABILITY);
    }
  }
}
