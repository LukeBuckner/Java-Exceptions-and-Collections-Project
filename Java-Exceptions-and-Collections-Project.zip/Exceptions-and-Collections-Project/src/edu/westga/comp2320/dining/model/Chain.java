package edu.westga.comp2320.dining.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a chain of restaurants.
 * A Chain manages a collection of restaurants.
 *
 * @author Your Name
 * @version Fall 2023
 */
public class Chain {

  private String name;
  private List<Restaurant> restaurants;

  /**
   * Creates a new Chain with the specified name.
   * Initializes an empty list of restaurants.
   *
   * @param name the name of the chain
   */
  public Chain(String name) {
    this.name = name;
    this.restaurants = new ArrayList<>();
  }

  /**
   * Gets the name of the chain.
   *
   * @return the name of the chain
   */
  public String getName() {
    return this.name;
  }

  /**
   * Gets the list of restaurants managed by this chain.
   *
   * @return the list of restaurants
   */
  public List<Restaurant> getRestaurants() {
    return this.restaurants;
  }

  /**
   * Returns the number of restaurants in the chain.
   *
   * @return the number of restaurants
   */
  public int size() {
    return this.restaurants.size();
  }

  /**
   * Adds a restaurant to the chain if it doesn't already exist.
   *
   * @param restaurant the restaurant to add
   */
  public void add(Restaurant restaurant) {
    // Check if a restaurant with the same name already exists
    boolean restaurantExists = this.restaurants.stream()
                .anyMatch(existingRestaurant 
                    -> existingRestaurant.getName().equalsIgnoreCase(restaurant.getName()));

    if (!restaurantExists) {
      this.restaurants.add(restaurant);
    }
  }

  /**
   * Returns a formatted string representation of the chain.
   *
   * @return a string in the format ""&lt;name&gt;'s chain of &lt;number&gt; restaurants"
     */
  @Override
    public String toString() {
    return this.name + "'s chain of " + this.size() + " restaurants";
  }
}
