package edu.westga.comp2320.dining.model;

import edu.westga.comp2320.dining.resources.Ui;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * This class represents the history of payments for a table.
 *
 * @author COMP2320
 * @version Fall 2023
 */
public class PaymentHistory {

  private ArrayList<Double> payments;

  /**
   * Instantiate a new PaymentHistory object.
   *
   * @precondition none
   * @postcondition size() == 0
   */
  public PaymentHistory() {
    this.payments = new ArrayList<Double>();
  }

  /**
   * Add payment to this paymentHistory.
   *
   * @precondition payment > 0
   * @postcondition size() == size()@prev + 1
   * @param payment the specified payment
   * @return true if added, false otherwise
   */
  public boolean add(double payment) {
    if (payment <= 0) {
      throw new IllegalArgumentException(Ui.NON_POSITIVE_PAYMENT);
    }
    return this.payments.add(payment);
  }

  /**
   * Get size of this payment history.
   *
   * @precondition none
   * @postcondition none
   * @return size of this payment history
   */
  public int size() {
    return this.payments.size();
  }

  /**
   * Get the average payment in this payment history.
   *
   * @precondition none
   * @postcondition none
   * @return average number of seats
   */
  public double getAverage() {
    if (this.payments.size() == 0) {
      return 0.0;
    }
    double total = 0.0;
    for (double payment : this.payments) {
      total += payment;
    }
    double average = total / this.size();
    return average;
  }

  /**
   * Get the list of payments in this payment history.
   *
   * @precondition none
   * @postcondition none
   * @return the list of payments
   */
  public List<Double> getPayments() {
    return new ArrayList<>(this.payments);
  }

  /**
   * Get the highest payment in this payment history.
   *
   * @precondition none
   * @postcondition none
   * @return the highest payment, or 0.0 if the collection is empty
   */
  public double getHighestPayment() {
    if (this.payments.isEmpty()) {
      return 0.0;
    }
    return Collections.max(this.payments);
  }

  /**
   * Get the lowest payment in this payment history.
   *
   * @precondition none
   * @postcondition none
   * @return the lowest payment, or 0.0 if the collection is empty
   */
  public double getLowestPayment() {
    if (this.payments.isEmpty()) {
      return 0.0;
    }
    return Collections.min(this.payments);
  }
}
