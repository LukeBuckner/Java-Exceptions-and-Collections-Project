
package edu.westga.comp2320.dining.model;

import edu.westga.comp2320.dining.resources.Ui;

/**
 * The data class Table.
 *
 * @author COMP2320
 * @version Fall 2023
 */
public class Table {

  public static final int MIN_TABLE_NUMBER = 1;
  public static final int MAX_TABLE_NUMBER = 25;
  public static final int MIN_NUMBER_SEATS = 2;
  public static final int MAX_NUMBER_SEATS = 20;

  private int tableNumber;
  private int numberOfSeats;
  private boolean availability;
  private PaymentHistory paymentHistory;

  /**
   * Instantiate a Table object with specified values.
   *
   * @precondition MIN_TABLE_NUMBER <= tableNumber <= MAX_TABLE_NUMBER &&
   *               MIN_NUMBER_SEATS <= numberOfSeats <= MAX_NUMBER_SEATS
   * @postcondition getTableNumber() == tableNumber && getNumberOfSeats() ==
   *                numberOfSeats && isFree() && history != null
   * @param tableNumber   the number of this table
   * @param numberOfSeats the number of seats at this table
   */
  public Table(int tableNumber, int numberOfSeats) {
    if (tableNumber < MIN_TABLE_NUMBER || tableNumber > MAX_TABLE_NUMBER) {
      throw new IllegalArgumentException(Ui.TABLE_NUMBER_OUT_OF_BOUNDS);
    }
    if (numberOfSeats < MIN_NUMBER_SEATS || numberOfSeats > MAX_NUMBER_SEATS) {
      throw new IllegalArgumentException(Ui.NUMBER_SEATS_OUT_OF_BOUNDS);
    }
    this.tableNumber = tableNumber;
    this.numberOfSeats = numberOfSeats;
    this.paymentHistory = new PaymentHistory();
  }

  /**
   * Get the table number.
   *
   * @precondition none
   * @postcondition none
   * @return the tableNumber
   */
  public int getTableNumber() {
    return this.tableNumber;
  }

  /**
   * Get the availability of this table.
   *
   * @precondition none
   * @postcondition none
   * 
   * @return true if available, false otherwise
   */
  public boolean isAvailable() {
    return this.availability;
  }

  /**
   * Set the availability of this table.
   *
   * @precondition none
   * @postcondition isFree() == free
   * @param available the availability to set
   */
  public void setAvailable(boolean available) {
    this.availability = available;
  }

  /**
   * Get the number of seats.
   *
   * @precondition none
   * @postcondition none
   * @return the numberOfSeats
   */
  public int getNumberOfSeats() {
    return this.numberOfSeats;
  }

  /**
   * Get payment history of this table.
   *
   * @precondition none
   * @postcondition none
   * @return the paymentHistory
   */
  public PaymentHistory getPaymentHistory() {
    return this.paymentHistory;
  }

  /**
   * Collect payment to this table.
   *
   * @param payment the specified amount
   * @return true if added to history, false otherwise
   */
  public boolean collectPayment(double payment) {
    return this.paymentHistory.add(payment);
  }

}
