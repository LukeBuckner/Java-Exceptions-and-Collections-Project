package edu.westga.comp2320.dining.model;

import edu.westga.comp2320.dining.resources.Ui;
import java.util.ArrayList;
import java.util.List;

/**
 * The wrapper class Restaurant.
 *
 * @author COMP2320
 * @version Fall 2023
 */
public class Restaurant {

  public static final int MIN_RATING = 1;
  public static final int MAX_RATING = 10;
  public static final int DEFAULT_RATING_VALUE = 0;

  private String name;
  private int rating;
  private ArrayList<Table> tables;

  /**
   * Instantiate a new Restaurant object.
   *
   * @precondition name != null && name.isBlank() && MIN_RATING <= rating <=
   *               MAX_RATING
   * @postcondition getName().equals(name) && getRating() == rating && size() == 0
   * @param name   the specified name
   * @param rating the specified rating
   */
  public Restaurant(String name, int rating) {
    if (name == null) {
      throw new IllegalArgumentException(Ui.NULL_NAME);
    }
    if (name.isBlank()) {
      throw new IllegalArgumentException(Ui.BLANK_NAME);
    }
    if (rating < MIN_RATING || rating > MAX_RATING) {
      throw new IllegalArgumentException(Ui.RATING_OUT_OF_BOUNDS);
    }
    this.name = name;
    this.rating = rating;
    this.tables = new ArrayList<Table>();
  }

  /**
   * Instantiate a new Restaurant object.
   *
   * @precondition none
   * @postcondition getName().equals("") && getRating() == DEFAULT_RATING_VALUE &&
   *                size() == 0
   */
  public Restaurant() {
    this.name = "";
    this.rating = DEFAULT_RATING_VALUE;
    this.tables = new ArrayList<Table>();
  }

  /**
   * Add the table to this restaurant.
   *
   * @precondition table != null && table.getNumber() is unique to this restaurant
   * @postcondition size() == size()@prev + 1
   * @param table the table to add
   * @return true if table added, false otherwise
   */
  public boolean add(Table table) {
    if (table == null) {
      throw new IllegalArgumentException(Ui.NULL_TABLE);
    }
    if (this.contains(table)) {
      throw new IllegalArgumentException(Ui.EXISTING_TABLE);
    }
    return this.tables.add(table);
  }

  /**
   * Check if another table with the same number as the specified table is already
   * in the restaurant.
   *
   * @precondition table != null
   * @postcondition none
   * @param table - the specified table
   * @return true if table with same number exists, false otherwise
   */
  public boolean contains(Table table) {
    if (table == null) {
      throw new IllegalArgumentException(Ui.NULL_TABLE);
    }
    for (Table currTable : this.tables) {
      if (currTable.getTableNumber() == table.getTableNumber()) {
        return true;
      }
    }
    return false;
  }

  /**
   * Get the number of seats at the largest table.
   *
   * @precondition none
   * @postcondition none
   * @return number seats at largest table
   */
  public int getNumberSeatsAtLargestTable() {
    if (this.tables.size() == 0) {
      return 0;
    }
    int maxNumSeats = Integer.MIN_VALUE;
    for (Table table : this.tables) {
      if (table.getNumberOfSeats() > maxNumSeats) {
        maxNumSeats = table.getNumberOfSeats();
      }
    }
    return maxNumSeats;
  }

  /**
   * Get the average number of seats per table.
   *
   * @precondition none
   * @postcondition none
   * @return average number of seats
   */
  public double getAverageNumberSeats() {
    if (this.tables.size() == 0) {
      return 0.0;
    }
    double total = 0.0;
    for (Table table : this.tables) {
      total += table.getNumberOfSeats();
    }
    double average = total / this.size();
    return average;
  }

  /**
   * Get the name of this restaurant.
   *
   * @precondition none
   * @postcondition none
   * @return the name
   */
  public String getName() {
    return this.name;
  }

  /**
   * Get the rating of this Restaurant.
   *
   * @precondition none
   * @postcondition none
   * @return the rating
   */
  public int getRating() {
    return this.rating;
  }

  /**
   * Get the tables of this restaurant.
   *
   * @precondition none
   * @postcondition none
   * @return the tables
   */
  public ArrayList<Table> getTables() {
    return this.tables;
  }

  /**
   * Set the name of this Restaurant.
   *
   * @precondition name != null && name.isBlank()
  * @postcondition getName().equals(name)
   * @param name the name to set
   */

  public void setName(String name) {
    if (name == null) {
      throw new IllegalArgumentException(Ui.NULL_NAME);
    }
    if (name.isBlank()) {
      throw new IllegalArgumentException(Ui.BLANK_NAME);
    }
    this.name = name;
  }

  /**
   * Set the rating of this Restaurant.
   *
   * @precondition MIN_RATING <= rating <= MAX_RATING
   * @postcondition getRating() == rating
   * @param rating the rating to set
   */

  public void setRating(int rating) {
    if (rating < MIN_RATING || rating > MAX_RATING) {
      throw new IllegalArgumentException(Ui.RATING_OUT_OF_BOUNDS);
    }
    this.rating = rating;
  }

  /**
   * Set the tables of this Restaurant.
   *
   * @precondition tables != null
   * @postcondition getTables() == tables
   * @param tables the tables to set
   */

  public void setTables(ArrayList<Table> tables) {
    if (tables == null) {
      throw new IllegalArgumentException(Ui.NULL_TABLES);
    }
    this.tables = tables;
  }

  /**
   * Get the size of this Restaurant.
   *
   * @precondition none
   * @postcondition none
   * @return the size of this restaurant
   */
  public int size() {
    return this.tables.size();
  }

  @Override
  public String toString() {
    return this.name + ": " + this.size() + " tables, " + this.getCapacity() + " clients";
  }

  private int getCapacity() {
    int capacity = 0;
    for (Table table : this.tables) {
      capacity += table.getNumberOfSeats();
    }
    return capacity;
  }


  /**
   * Calculates the total number of payments made in the restaurant.
   *
   * @return The total number of payments across all tables.
   */
  public int getTotalNumberOfPayments() {
    int totalPayments = 0;
    for (Table table : this.tables) {
      totalPayments += table.getPaymentHistory().size();
    }
    return totalPayments;
  }

  /**
   * Retrieves the highest payment made in the restaurant.
   *
   * @return The highest payment amount among all tables, or 0.0 if there are no payments.
   */
  public double getHighestPayment() {
    double highestPayment = 0.0;
    for (Table table : this.tables) {
      double tableHighestPayment = table.getPaymentHistory().getHighestPayment();
      highestPayment = Math.max(highestPayment, tableHighestPayment);
    }
    return highestPayment;
  }

  /**
   * Retrieves the lowest payment made in the restaurant.
   *
   * @return The lowest payment amount among all tables, or 0.0 if there are no payments.
   */
  public double getLowestPayment() {
    double lowestPayment = Double.MAX_VALUE;
    for (Table table : this.tables) {
      double tableLowestPayment = table.getPaymentHistory().getLowestPayment();
      lowestPayment = Math.min(lowestPayment, tableLowestPayment);
    }
    return lowestPayment == Double.MAX_VALUE ? 0.0 : lowestPayment;
  }

  /**
   * Retrieves all payments made in the restaurant.
   *
   * @return A list of all payments from all tables, or an empty list if there are no payments.
   */
  public List<Double> getAllPayments() {
    List<Double> allPayments = new ArrayList<>();
    for (Table table : this.tables) {
      allPayments.addAll(table.getPaymentHistory().getPayments());
    }
    return allPayments;
  }

}
