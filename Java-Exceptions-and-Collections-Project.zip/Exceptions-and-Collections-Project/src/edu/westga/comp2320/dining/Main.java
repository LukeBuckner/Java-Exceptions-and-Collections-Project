package edu.westga.comp2320.dining;

import edu.westga.comp2320.dining.datatier.DataFileReader;
import edu.westga.comp2320.dining.datatier.DataFileWriter;
import edu.westga.comp2320.dining.datatier.ReportFileWriter;
import edu.westga.comp2320.dining.model.Chain;
import java.io.File;

/**
 * This class represents the starting point of the application.
 *
 * @author COMP2320
 * @version Fall 2023
 */
public class Main {

  public static final String YOUR_NAME = "Luke Buckner";
  public static final String INPUT_FILE = "input.csv";
  public static final String OUTPUT_FILE = "output.csv";
  public static final String REPORT_FILE = "report.txt";

  /**
   * Launches the application.
   *
   * @precondition none
   * @postcondition none
   * @param args - not used
   */
  public static void main(String[] args) {

    // TODO Part 1
    Chain chain = new Chain(YOUR_NAME);

    // TODO Part 2-A
    File inputFile = new File(INPUT_FILE);
    DataFileReader dataFileReader = new DataFileReader(inputFile);
    dataFileReader.loadRestaurantData(chain);

    // TODO Part 2-B
    File outputFile = new File(OUTPUT_FILE);
    DataFileWriter dataFileWriter = new DataFileWriter(outputFile);
    dataFileWriter.writeRestaurantData(chain);

    // TODO Part 3
    File reportFile = new File(REPORT_FILE);
    ReportFileWriter reportFileWriter = new ReportFileWriter(reportFile);
    reportFileWriter.writeReportData(chain, 1400);
  }

}
